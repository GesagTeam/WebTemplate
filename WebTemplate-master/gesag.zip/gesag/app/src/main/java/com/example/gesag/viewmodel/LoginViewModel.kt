package com.example.gesag.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.gesag.repository.AuthRepository
import kotlinx.coroutines.launch

class LoginViewModel(private val authRepository: AuthRepository = AuthRepository()) : ViewModel() {

    fun login(username: String, password: String) {
        viewModelScope.launch {
            authRepository.login(username, password)
        }
    }
}
