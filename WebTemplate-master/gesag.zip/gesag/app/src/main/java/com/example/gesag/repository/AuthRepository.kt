package com.example.gesag.repository

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AuthRepository {

    suspend fun login(username: String, password: String) {
        withContext(Dispatchers.IO) {
            // Perform login logic here, e.g., network request to API
        }
    }
}
