package com.example.gesag
import com.example.gesag.ui.LoginScreen
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.gesag.ui.theme.GESAGTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GESAGTheme {
                LoginScreen()
            }
        }
    }
}
