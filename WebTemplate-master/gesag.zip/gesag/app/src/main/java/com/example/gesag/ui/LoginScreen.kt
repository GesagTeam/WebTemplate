package com.example.gesag.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.gesag.R
import com.example.gesag.viewmodel.LoginViewModel

@Composable
fun LoginScreen(viewModel: LoginViewModel = viewModel()) {
    val username = remember { mutableStateOf("") }
    val password = remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Logo
        Image(
            painter = painterResource(id = R.drawable.logo), // Replace with your main logo drawable
            contentDescription = "App Logo",
            modifier = Modifier.size(300.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Username Field with Icon
        OutlinedTextField(
            value = username.value,
            onValueChange = { username.value = it },
            label = { Text("username e.g., rami99") },
            leadingIcon = {
                Icon(
                    painter = painterResource(id = R.drawable.ic_username), // Replace with your username icon drawable
                    contentDescription = "Username Icon",
                    modifier = Modifier.size(16.dp, 24.dp), // Sets width to 16.dp and height to 24.dp
                    tint = Color.Unspecified // Keeps the original color of the PNG
                )
            },
            modifier = Modifier.fillMaxWidth()
        )

// Password Field with Icon
        OutlinedTextField(
            value = password.value,
            onValueChange = { password.value = it },
            label = { Text("password") },
            leadingIcon = {
                Icon(
                    painter = painterResource(id = R.drawable.ic_password), // Replace with your password icon drawable
                    contentDescription = "Password Icon",
                    modifier = Modifier.size(16.dp, 24.dp), // Sets width to 16.dp and height to 24.dp
                    tint = Color.Unspecified // Keeps the original color of the PNG
                )
            },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )

        // Forgot Password - Positioned to the End
        Text(
            text = "Forgot your password?",
            color = Color(0xFFFF9800), // Yellow color for the text
            fontSize = 14.sp,
            modifier = Modifier
                .align(Alignment.End) // Aligns the text to the end
                .clickable { /* Handle forgot password action */ }
        )

        Spacer(modifier = Modifier.height(16.dp))
        // Login Button
        Button(
            onClick = { viewModel.login(username.value, password.value) },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9800))
        ) {
            Text(text = "Login", color = Color.White)
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Create Account - Centered at Bottom
        Row(
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "You don’t have an account? ",
                color = Color.Black, // Black color for this part
                fontSize = 14.sp,
                textAlign = TextAlign.Center
            )
            Text(
                text = "Create Account",
                color = Color(0xFFFFA500), // Orange color for "Create Account"
                fontSize = 14.sp,
                modifier = Modifier.clickable { /* Handle create account action */ }
            )
        }
    }
}
