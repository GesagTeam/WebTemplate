package com.example.gesag.model

data class User(
    val username: String,
    val password: String
)
